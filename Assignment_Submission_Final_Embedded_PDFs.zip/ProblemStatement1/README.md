# Problem Statement 1 - FreeRTOS Implementation

## Overview
This program demonstrates inter-task communication in FreeRTOS using a queue.

### Features:
- Creates a queue `Queue1` (length = 5) of type `Data_t`
- Task1 (`ExampleTask1`) sends data every 500ms exactly using `vTaskDelayUntil`
- Task2 (`ExampleTask2`) receives and processes the queue data

### Behavior:
| Condition | Action |
|------------|---------|
| `dataID == 0` | Deletes ExampleTask2 |
| `dataID == 1` and `DataValue == 0` | Increases ExampleTask2 priority by 2 |
| `dataID == 1` and `DataValue == 1` | Restores ExampleTask2 priority |
| `dataID == 1` and `DataValue == 2` | Deletes ExampleTask2 |

### How to Run
1. Load the code in STM32CubeIDE or any FreeRTOS-supported platform.
2. Include FreeRTOS source and header files.
3. Build and flash to target board or run in simulator.

### Expected Output
Console prints similar to:
```
Received -> ID: 1  Value: 0
Priority Increased
Received -> ID: 1  Value: 1
Priority Restored
```
