# Problem Statement 2 - NPM1100 Evaluation Board

## Overview
This folder contains schematic, PCB layout, and BOM for a compact nPM1100-based power evaluation board.

### Design Features
- 5V input to regulated 3.3V output
- Li-ion battery connector
- LEDs for Power Good and Charging indication
- Compact 35x35mm 2-layer PCB

### Files
- **Schematic.pdf** – Circuit schematic diagram of the design.
- **pcb_design.pdf** – Component placement and routing overview.
- **BOM.csv** – Bill of Materials listing components and quantities.

### Notes
Follow Nordic datasheet layout recommendations for QFN thermal pad connection.
