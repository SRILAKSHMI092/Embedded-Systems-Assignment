
/*
 * ProblemStatement1/main.c
 * FreeRTOS example implementing ExampleTask1 and ExampleTask2 using a queue.
 *
 * Build notes:
 * - Assumes FreeRTOS headers and config available.
 * - Replace platform-specific includes (e.g., UART init / printf) as needed.
 */

#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include <stdint.h>
#include <stdio.h>

/* Data type definition */
typedef struct {
    uint8_t dataID;
    int32_t DataValue;
} Data_t;

/* Global variables that are assumed updated elsewhere in the system */
volatile uint8_t G_DataID = 1;
volatile int32_t G_DataValue = 0;

/* Handles */
TaskHandle_t TaskHandle_1 = NULL;
TaskHandle_t TaskHandle_2 = NULL;
QueueHandle_t Queue1 = NULL;

/* Prototypes */
void ExampleTask1(void *pV);
void ExampleTask2(void *pV);

/* A simple thread-safe debug print wrapper if printf isn't thread-safe on your platform.
   For many embedded targets, replace with UART transmit implementation. */
static void debug_printf(const char *fmt, ...)
{
    va_list args;
    va_start(args, fmt);
    vprintf(fmt, args); /* On hosted platforms this works; on microcontrollers replace accordingly. */
    va_end(args);
}

/* ExampleTask1: Sends Data_t to Queue1 exactly every 500 ms */
void ExampleTask1(void *pV)
{
    Data_t txData;
    /* Use vTaskDelayUntil to ensure the delay is exact */
    TickType_t xLastWakeTime = xTaskGetTickCount();
    const TickType_t xPeriod = pdMS_TO_TICKS(500);

    for (;;)
    {
        txData.dataID = (uint8_t)G_DataID;
        txData.DataValue = (int32_t)G_DataValue;

        if (xQueueSend(Queue1, &txData, 0) == pdPASS)
        {
            /* Replace debug_printf with your UART print if needed */
            debug_printf("[Task1] Sent -> ID:%u Value:%ld\r\n", txData.dataID, (long)txData.DataValue);
        }
        else
        {
            debug_printf("[Task1] Queue full, send failed\r\n");
        }

        /* Delay until next exact period */
        vTaskDelayUntil(&xLastWakeTime, xPeriod);
    }
}

/* ExampleTask2: Receives from Queue1 and applies logic */
void ExampleTask2(void *pV)
{
    Data_t rxData;
    /* Store the original priority so we can restore it */
    UBaseType_t originalPriority = uxTaskPriorityGet(NULL);
    UBaseType_t currentPriority = originalPriority;

    for (;;)
    {
        /* Wait indefinitely for data */
        if (xQueueReceive(Queue1, &rxData, portMAX_DELAY) == pdPASS)
        {
            debug_printf("[Task2] Received -> ID:%u Value:%ld\r\n", rxData.dataID, (long)rxData.DataValue);

            /* Evaluate conditions */
            if (rxData.dataID == 0)
            {
                debug_printf("[Task2] dataID==0 -> Deleting ExampleTask2\r\n");
                /* Delete self */
                vTaskDelete(NULL);
            }
            else if (rxData.dataID == 1)
            {
                /* Allow processing of DataValue member */
                if (rxData.DataValue == 0)
                {
                    /* Increase priority by 2 from original */
                    currentPriority = originalPriority + 2;
                    vTaskPrioritySet(TaskHandle_2, currentPriority);
                    debug_printf("[Task2] DataValue==0 -> Priority increased to %u\r\n", (unsigned)currentPriority);
                }
                else if (rxData.DataValue == 1)
                {
                    /* Decrease/reset priority if previously increased */
                    currentPriority = originalPriority;
                    vTaskPrioritySet(TaskHandle_2, currentPriority);
                    debug_printf("[Task2] DataValue==1 -> Priority reset to %u\r\n", (unsigned)currentPriority);
                }
                else if (rxData.DataValue == 2)
                {
                    debug_printf("[Task2] DataValue==2 -> Deleting ExampleTask2\r\n");
                    vTaskDelete(NULL);
                }
                else
                {
                    debug_printf("[Task2] DataValue==%ld -> No special action\r\n", (long)rxData.DataValue);
                }
            }
            else
            {
                debug_printf("[Task2] Unknown dataID %u -> Ignoring\r\n", rxData.dataID);
            }
        }
    }
}

/* main - create queue and tasks, then start scheduler */
int main(void)
{
    /* Platform initialisation here (clock, UART, peripherals) */
    /* ... */

    /* Create queue: length 5, each item is sizeof(Data_t) */
    Queue1 = xQueueCreate(5, sizeof(Data_t));
    if (Queue1 == NULL)
    {
        /* Queue creation failed */
        debug_printf("Queue creation failed! Halting.\r\n");
        for (;;);
    }

    /* Create tasks
       Task1: higher priority to ensure it reliably sends; adjust stack sizes and priorities per target.
       Task2: lower priority initially.
    */
    BaseType_t ret;

    ret = xTaskCreate(ExampleTask1, "ExampleTask1", configMINIMAL_STACK_SIZE + 128, NULL, 3, &TaskHandle_1);
    if (ret != pdPASS)
    {
        debug_printf("Failed to create ExampleTask1\r\n");
        for (;;);
    }

    ret = xTaskCreate(ExampleTask2, "ExampleTask2", configMINIMAL_STACK_SIZE + 128, NULL, 2, &TaskHandle_2);
    if (ret != pdPASS)
    {
        debug_printf("Failed to create ExampleTask2\r\n");
        for (;;);
    }

    /* Start scheduler */
    vTaskStartScheduler();

    /* Should never reach here */
    for (;;);
    return 0;
}
