/* main.c
   Problem Statement 1 - FreeRTOS demonstration
   Implements two tasks and one queue as per assignment requirements.
*/

#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include <stdio.h>
#include <stdint.h>

typedef struct {
    uint8_t dataID;
    int32_t DataValue;
} Data_t;

extern volatile uint8_t G_DataID;
extern volatile int32_t G_DataValue;

QueueHandle_t Queue1;
TaskHandle_t TaskHandle_1;
TaskHandle_t TaskHandle_2;
UBaseType_t ExampleTask2_CreationPriority = 1;

void ExampleTask1(void *pV);
void ExampleTask2(void *pV);

int main(void)
{
    Queue1 = xQueueCreate(5, sizeof(Data_t));
    xTaskCreate(ExampleTask1, "ExampleTask1", configMINIMAL_STACK_SIZE + 100, NULL, 2, &TaskHandle_1);
    xTaskCreate(ExampleTask2, "ExampleTask2", configMINIMAL_STACK_SIZE + 150, NULL, 1, &TaskHandle_2);
    vTaskStartScheduler();
    for(;;);
}

void ExampleTask1(void *pV)
{
    TickType_t xLastWakeTime = xTaskGetTickCount();
    const TickType_t xPeriod = pdMS_TO_TICKS(500);
    Data_t data;
    for(;;)
    {
        data.dataID = G_DataID;
        data.DataValue = G_DataValue;
        xQueueSend(Queue1, &data, 10);
        vTaskDelayUntil(&xLastWakeTime, xPeriod);
    }
}

void ExampleTask2(void *pV)
{
    Data_t rx;
    for(;;)
    {
        if(xQueueReceive(Queue1, &rx, portMAX_DELAY) == pdPASS)
        {
            printf("Received -> ID: %d  Value: %ld\n", rx.dataID, (long)rx.DataValue);
            if(rx.dataID == 0) vTaskDelete(NULL);
            if(rx.dataID == 1 && rx.DataValue == 0) vTaskPrioritySet(TaskHandle_2, ExampleTask2_CreationPriority + 2);
            if(rx.dataID == 1 && rx.DataValue == 1) vTaskPrioritySet(TaskHandle_2, ExampleTask2_CreationPriority);
            if(rx.dataID == 1 && rx.DataValue == 2) vTaskDelete(NULL);
        }
    }
}
