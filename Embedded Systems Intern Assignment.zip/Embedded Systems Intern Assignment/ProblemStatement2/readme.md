
# ProblemStatement1

This folder contains the FreeRTOS implementation for Problem Statement 1.

## Files
- main.c : FreeRTOS application implementing ExampleTask1 and ExampleTask2 with Queue1.

## How it works
- `ExampleTask1` sends `Data_t` to `Queue1` every 500 ms using `vTaskDelayUntil()` to ensure exact timing.
- `ExampleTask2` waits on the queue and applies logic:
  - If dataID == 0 -> delete itself.
  - If dataID == 1 -> process DataValue:
    - DataValue == 0 : increase ExampleTask2 priority by 2 from original.
    - DataValue == 1 : reset priority to original.
    - DataValue == 2 : delete itself.
- Console/debug prints are present for tracing.

## Integration notes
- Replace `debug_printf()` with your board's UART transmit function if `printf` is not available or thread-unsafe.
- Adjust stack sizes (`configMINIMAL_STACK_SIZE + 128`) according to your MCU.
- Ensure FreeRTOSConfig.h provides `configUSE_PREEMPTION`, `configTICK_RATE_HZ`, etc.
