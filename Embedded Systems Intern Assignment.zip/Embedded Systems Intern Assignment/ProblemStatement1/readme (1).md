
# ProblemStatement2

This folder contains the Bill of Materials and instructions to create the KiCAD schematic and PCB for the nPM1100-based evaluation board.

## Requirements & Constraints
- Output: 3.0V regulated by nPM1100.
- Charge current: 200 mA (CC).
- Input: 5V ripple-free (1A capable) via 2-pin header.
- Board size: <= 35mm x 35mm.
- Max 4 layers.
- Use only SMD components sized 0403 to 0805.
- All SMD parts top-mounted.
- Use KiCAD (open-source) for design.

## Files provided
- BOM.csv : Suggested BOM entries and reference designators.
- README (this file) : Steps to create schematic and PCB.

## Suggested Schematic Outline (follow datasheet)
1. Place U1 as nPM1100 QFN24 symbol and footprint.
2. Connect input 5V to VIN pin via J2 header.
3. Connect battery connector J1 to BAT pins.
4. Place required decoupling capacitors near VIN, VOUT and BAT as per datasheet (C1..C3).
5. Add LEDs with series resistors to indicate CHARGE and POWER.
6. Add a simple voltage divider (R2 + R?) from BAT to an MCU ADC pin for battery measurement (bonus).
7. Add 0-ohm jumper for optional connections or measurement routing.
8. Follow recommended layout: short traces for power pins, solid ground plane (split if needed), thermal vias under QFN pad per datasheet.

## PCB Layout tips
- Use a solid ground pour on inner or bottom layer.
- Route VIN and BAT with wide traces (min 30-40 mil, or use copper pour).
- Keep decoupling caps close to U1 pins.
- Place LEDs near the board edge with clear silkscreen.
- Respect 35x35 mm board outline.

## How to produce PDF outputs for submission
- In KiCAD Eeschema, File -> Export -> Schematic PDF
- In PCBNew, File -> Fabrication Outputs -> PCB in PDF (or plot to PDF)
- Save schematic.pdf and pcb_design.pdf into ProblemStatement2 folder.

Good luck!
